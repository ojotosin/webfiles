<div class="banner-slider" style="background-image: url(<?php echo base_url(); ?>public/uploads/<?php echo $setting['banner_verify_registration']; ?>)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>Registration Successful</h1>
		</div>
	</div>
</div>

<div class="login-area bg-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="login-form" style="padding-top:50px;padding-bottom:50px;font-size:24px;color:green;text-align: center;">
					Registration is Successful. Thank you. You can now login to our system. <br>
					<a href="<?php echo base_url(); ?>traveller/login" class="btn btn-warning btn-lg mt_20">Click here to login</a>
				</div>
			</div>
		</div>
	</div>
</div>